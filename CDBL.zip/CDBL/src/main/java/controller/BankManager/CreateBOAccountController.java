package controller.BankManager;

import javafx.event.ActionEvent;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class CreateBOAccountController {
    @javafx.fxml.FXML
    private TextField BankAccountNumberTextField;
    @javafx.fxml.FXML
    private TextField KycTextField;
    @javafx.fxml.FXML
    private TextField PhoneNumberTextfield;
    @javafx.fxml.FXML
    private TextField NomineeIDTextfield;
    @javafx.fxml.FXML
    private TextField BOAccountIDTextfield;
    @javafx.fxml.FXML
    private TextField AdressTextfield;
    @javafx.fxml.FXML
    private TextField EmailTextField;
    @javafx.fxml.FXML
    private TextField BondTextField;
    @javafx.fxml.FXML
    private DatePicker DOBdoj;
    @javafx.fxml.FXML
    private TextField PasswordTextField;
    @javafx.fxml.FXML
    private TextField InvestorNameTextField;


    @javafx.fxml.FXML
    public void OnActionBankAccountNumberLinkButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void OnActionNomineeIdButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void OnActionSharesLinkButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void OnActionSharesAddmoreButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void OnActionLinkEmailButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void OnActionBondLinkButtonClick(ActionEvent actionEvent) {
    }



    @javafx.fxml.FXML
    public void OnActionBondsAddmoreButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void OnActionKycUploadButtonClick(ActionEvent actionEvent) {
    }
    @javafx.fxml.FXML
    public void OnActionGenerateButtonClick(ActionEvent actionEvent) {
        // Generate unique BO ID
        String boId = "BO" + System.currentTimeMillis() % 100000;
        BOAccountIDTextfield.setText(boId);
    }

    @javafx.fxml.FXML
    public void OnActionVerifyAndCreateBoAccount(ActionEvent actionEvent) {
        // Validate all fields
        if (!validateInputs()) return;

        // Create new investor
        IndividualInvestor investor = new IndividualInvestor(
                InvestorNameTextField.getText(),
                EmailTextField.getText(),
                BOAccountIDTextfield.getText()
        );

        // Set additional details
        investor.setDateOfBirth(DOBdoj.getValue());
        investor.setPhone(PhoneNumberTextfield.getText());
        investor.setAddress(AdressTextfield.getText());
        investor.setPassword(PasswordTextField.getText());
        investor.setNomineeId(NomineeIDTextfield.getText());
        investor.setBankAccount(BankAccountNumberTextField.getText());

        // Save to file
        DataLoader.saveInvestor(investor);
        showAlert("Success", "BO Account created successfully");
    }

    private boolean validateInputs() {
        if (InvestorNameTextField.getText().isEmpty() ||
                EmailTextField.getText().isEmpty() ||
                PhoneNumberTextfield.getText().isEmpty()) {
            showAlert("Error", "Please fill all required fields");
            return false;
        }
        return true;
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(title.equals("Error") ? Alert.AlertType.ERROR : Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
}
