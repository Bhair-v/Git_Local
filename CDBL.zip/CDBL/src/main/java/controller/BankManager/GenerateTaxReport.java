package controller.BankManager;

public class GenerateTaxReport {
}
