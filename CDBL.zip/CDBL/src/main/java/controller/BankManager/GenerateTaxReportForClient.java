package controller.BankManager;

public class GenerateTaxReportForClient {
}
