package CdblUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class BankManager {
    @javafx.fxml.FXML
    private Button AssignRelationshipOfficerButton;
    @javafx.fxml.FXML
    private TextField BankTextField;
    @javafx.fxml.FXML
    private Button openBOaccountButton;
    @javafx.fxml.FXML
    private TextField BankManagerIDTextField;
    @javafx.fxml.FXML
    private Button generateTaxReportButton;
    @javafx.fxml.FXML
    private Button GenarateComplianceReportButton;
    @javafx.fxml.FXML
    private TextField BankBranchTextField;
    @javafx.fxml.FXML
    private Button updateClientInfoButton;
    @javafx.fxml.FXML
    private Button RespondToInquiryButton;
    @javafx.fxml.FXML
    private Button TransferSecuritiesButton;

    @javafx.fxml.FXML
    public void onActionTransferSecuritiesButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionOpenBOaccountButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActiongenerateTaxReportButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionAssignRelationshipOfficerButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionRespondToInquiryButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionGenarateComplianceReportButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionupdateClientInfoButtonClick(ActionEvent actionEvent) {
    }
}
