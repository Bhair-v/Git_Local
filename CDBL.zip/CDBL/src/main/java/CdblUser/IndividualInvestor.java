package CdblUser;


import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;



public class IndividualInvestor extends User {
    public IndividualInvestor(String id, String name, String password, String email, String phone, String type) {
        super(id, name, password, email, phone, type);
    }


    @javafx.fxml.FXML
    private Button ViewPortofolioButton;
    @javafx.fxml.FXML
    private Button SubmitInquiryButton;
    @javafx.fxml.FXML
    private TextField BankTextField;
    @javafx.fxml.FXML
    private Button ViewCorporateActionsButton;
    @javafx.fxml.FXML
    private Button ViewMarketTrendsButton;
    @javafx.fxml.FXML
    private Button ViewTransactionHistoryButton;
    @javafx.fxml.FXML
    private Button PlaceSellOrderButton;
    @javafx.fxml.FXML
    private TextField InvestorIDTextField;
    @javafx.fxml.FXML
    private Button RequestInfoUpdateButton;
    @javafx.fxml.FXML
    private Button PlaceBuyOrderButton;



    @javafx.fxml.FXML
    public void onActionRequestInfoUpdateButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionViewPortofolioButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionViewMarketTrendsButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionSubmitInquiryButton(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionPlaceSellOrderButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionViewTransactionHistoryButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionPlaceBuyOrderButtonClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onActionViewCorporateActionsButtonClick(ActionEvent actionEvent) {
    }
}
